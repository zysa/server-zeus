CREATE TABLE IF NOT EXISTS samba_access_report (
    date DATE,
    username VARCHAR(24),
    operations BIGINT
);
