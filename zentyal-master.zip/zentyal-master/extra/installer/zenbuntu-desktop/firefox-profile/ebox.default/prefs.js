user_pref("browser.sessionstore.resume_from_crash", false);
user_pref("browser.startup.homepage", "https://localhost");
user_pref("browser.startup.homepage_override.mstone", "rv:1.9.0.18");
user_pref("browser.tabs.autoHide", true);
user_pref("browser.rights.3.shown", true);
user_pref("extensions.testpilot@labs.mozilla.install-event-fired", true);
user_pref("extensions.testpilot.alreadyCustomizedToolbar", true);
